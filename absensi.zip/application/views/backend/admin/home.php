<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h1 class="box-title">Selamat Datang, <?= $profile->nama;?></h1>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <center><img src="<?= base_url()?>assets/gambar/home.jpg" style="max-width:100%"></center>
    </div>
    <!-- /.box-body -->
  </div>
</section>